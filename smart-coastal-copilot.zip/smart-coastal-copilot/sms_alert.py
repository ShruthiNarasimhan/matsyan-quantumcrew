# sms_alert.py
import json
from datetime import datetime

def send_sms_alert(to, message):
    # Print to terminal (for demo)
    print(f"\n📩 Simulated SMS to {to}:\n{message}\n")

    # Save to sms_log.txt for verification
    log_data = {
        "to": to,
        "message": message,
        "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

    with open("sms_log.txt", "a") as f:
        f.write(json.dumps(log_data, indent=2) + "\n\n")
