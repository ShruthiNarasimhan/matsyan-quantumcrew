from flask import Flask, render_template, request, redirect, session, url_for, jsonify
import json
import hashlib
import os
from datetime import datetime
import requests

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# File paths
USER_FILE = 'data/users.json'
LOG_FILE = 'data/logs.json'

# Define zones and limits globally
ZONES = {
    "Zone A": 500,
    "Zone B": 400,
    "Zone C": 600
}

# Fast2SMS API setup
SMS_API_KEY = "YOUR_FAST2SMS_API_KEY"
SENDER_ID = "FSTSMS"

OFFICER_PHONE = "9876543210"
AUTHORITY_PHONE = "9123456789"

def send_sms_alert(phone, message):
    url = "https://www.fast2sms.com/dev/bulkV2"
    headers = {
        'authorization': SMS_API_KEY,
        'Content-Type': "application/json"
    }
    payload = {
        "route": "v3",
        "sender_id": SENDER_ID,
        "message": message,
        "language": "english",
        "flash": 0,
        "numbers": phone
    }
    response = requests.post(url, json=payload, headers=headers)
    print(f"SMS sent to {phone}: {response.text}")
    return response.text

# Load users from JSON file
def load_users():
    if os.path.exists(USER_FILE):
        with open(USER_FILE) as f:
            return json.load(f)
    return {"fisherman": {}, "officer": {}, "authority": {}}

# Save users to JSON file
def save_users(users):
    with open(USER_FILE, 'w') as f:
        json.dump(users, f, indent=2)

# Load catch logs from JSON file
def load_logs():
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE) as f:
            return json.load(f)
    return []

# Save catch logs to JSON file
def save_logs(logs):
    with open(LOG_FILE, 'w') as f:
        json.dump(logs, f, indent=2)

# Password hashing utility
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/select')
def select():
    return render_template('select.html')

@app.route('/auth', methods=['GET', 'POST'])
def auth():
    role = request.args.get('role')
    action = request.args.get('action', 'login')

    if role not in ['fisherman', 'officer', 'authority']:
        return redirect('/select')

    users = load_users()
    error = None

    if request.method == 'POST':
        gov_id = request.form.get('gov_id', '').strip()
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        mobile = request.form.get('mobile', '').strip()
        user_data = users.get(role, {})

        if action == 'signup':
            confirm_password = request.form.get('confirm_password', '')

            if not gov_id or not username or not password or not confirm_password:
                error = "❌ All fields are required for signup!"
            elif username in user_data:
                error = "❌ Username already exists!"
            elif password != confirm_password:
                error = "❌ Passwords do not match!"
            else:
                user_data[username] = {
                    "password": hash_password(password),
                    "gov_id": gov_id,
                    "mobile": mobile
                }

                users[role] = user_data
                save_users(users)
                return redirect(f'/auth?role={role}&action=login')

        elif action == 'login':
            if not gov_id or not username or not password:
                error = "❌ All fields are required for login!"
            elif username not in user_data:
                error = "❌ User does not exist!"
            elif user_data[username]['password'] != hash_password(password):
                error = "❌ Incorrect password!"
            elif user_data[username]['gov_id'] != gov_id:
                error = "❌ Incorrect Government ID!"
            else:
                session['username'] = username
                session['role'] = role
                return redirect(f'/{role}')

    return render_template('auth.html', role=role, action=action, error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/select')

@app.route('/fisherman', methods=['GET', 'POST'])
def fisherman_dashboard():
    if session.get('role') != 'fisherman':
        return redirect('/select')

    if 'temp_catches' not in session:
        session['temp_catches'] = []

    message = None

    if request.method == 'POST':
        zone = request.form.get('zone')
        species = request.form.get('species')
        weight = request.form.get('weight')
        effort = request.form.get('effort')
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')

        if not zone or not species or not weight or not effort:
            message = "❌ Please fill all fields."
        else:
            try:
                weight_f = float(weight)
                effort_f = float(effort)
                lat_f = float(latitude) if latitude else None
                lon_f = float(longitude) if longitude else None
            except ValueError:
                message = "❌ Weight, Effort, Latitude and Longitude must be numbers."
            else:
                new_catch = {
                    "zone": zone,
                    "species": species,
                    "weight": weight_f,
                    "effort": effort_f,
                    "latitude": lat_f,
                    "longitude": lon_f,
                    "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    "username": session['username']
                }
                temp_catches = session['temp_catches']
                temp_catches.append(new_catch)
                session['temp_catches'] = temp_catches
                message = f"✔️ Added catch: {species} in {zone}."

    delete_idx = request.args.get('delete')
    if delete_idx is not None:
        try:
            idx = int(delete_idx)
            temp_catches = session['temp_catches']
            if 0 <= idx < len(temp_catches):
                removed = temp_catches.pop(idx)
                session['temp_catches'] = temp_catches
                message = f"🗑️ Removed catch {removed['species']} from {removed['zone']}."
        except Exception:
            pass

    submit_all = request.args.get('submit_all')
    if submit_all == 'true':
        temp_catches = session.get('temp_catches', [])
        if temp_catches:
            logs = load_logs()
            for c in temp_catches:
                logs.append(c)
            save_logs(logs)
            session['temp_catches'] = []
            message = "✅ All catches submitted successfully."
        else:
            message = "⚠️ No catches to submit."

    legal_species = [
        "Indian Mackerel", "Pomfret", "Seer Fish", "Hilsa", "Sardine",
        "Tuna", "Barramundi", "Crab", "Shrimp", "Prawn", "Squid"
    ]
    zones = list(ZONES.keys())

    return render_template(
        'fisherman.html',
        temp_catches=session.get('temp_catches', []),
        message=message,
        legal_species=legal_species,
        zones=zones
    )

def get_zone_data_with_cpue():
    logs = load_logs()
    users = load_users()
    totals = {zone: 0 for zone in ZONES}
    efforts = {zone: 0 for zone in ZONES}
    logs_by_zone = {zone: [] for zone in ZONES}

    for log in logs:
        zone = log.get('zone')
        if zone in totals:
            totals[zone] += log.get('weight', 0)
            efforts[zone] += log.get('effort', 0)
            logs_by_zone[zone].append(log)

    zones = {}
    for zone, limit in ZONES.items():
        weight = totals[zone]
        effort = efforts[zone]
        cpue = round(weight / effort, 2) if effort > 0 else 0
        color = 'success' if weight < limit * 0.75 else 'warning' if weight < limit else 'danger'

        if color == 'danger':
            for log in logs_by_zone[zone]:
                username = log.get('username')
                mobile = users['fisherman'].get(username, {}).get('mobile')
                if mobile:
                    message_fisherman = (
                        f"⚠️ Alert from Smart Coastal Copilot:\n"
                        f"Overfishing detected in your fishing zone ({zone}).\n"
                        f"Your recent catch exceeds the safe limit.\n"
                        f"Please adhere to regulations to protect marine resources.\n"
                        f"Stay safe and responsible!"
                    )
                    send_sms_alert(mobile, message_fisherman)

            # Officer & Authority alerts
            for role in ['officer', 'authority']:
                for person, details in users[role].items():
                    mobile = details.get('mobile')
                    if mobile:
                        message_role = (
                            f"🚨 Alert: Overfishing in {zone}.\n"
                            f"Total Weight: {weight} kg\n"
                            f"Limit: {limit} kg\n"
                            f"Effort: {effort} hrs\n"
                            f"CPUE: {cpue}\n"
                            f"Please take necessary action."
                        )
                        send_sms_alert(mobile, message_role)

        zones[zone] = {
            "total_weight": weight,
            "limit": limit,
            "effort": effort,
            "cpue": cpue,
            "color": color,
            "logs": logs_by_zone[zone]
        }
    return zones

@app.route('/officer')
def officer_dashboard():
    if session.get('role') != 'officer':
        return redirect('/select')
    zones = get_zone_data_with_cpue()
    return render_template('officer.html', zones=zones)

@app.route('/authority')
def authority_dashboard():
    if session.get('role') != 'authority':
        return redirect('/select')
    zones = get_zone_data_with_cpue()
    return render_template('authority.html', zones=zones)

@app.route('/reset_logs', methods=['POST'])
def reset_logs():
    if session.get('role') != 'authority':
        return redirect('/select')
    save_logs([])
    return redirect('/authority')

if __name__ == '__main__':
    app.run(debug=True)
